module.exports.fxSwUpdate = require('./FxSwUpdate.js');
module.exports.fxFwUpdate = require('./FxFwUpdate.js');